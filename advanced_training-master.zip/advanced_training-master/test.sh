for entry in 0.005, 0.01, 0.0155
	do
	  echo $entry
done
