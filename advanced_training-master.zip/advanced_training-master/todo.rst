make toc
make notebooks for chapters
put 02 stuff from book into the advanced algorithm part

from scratch:
more feature selection
XGBoost
Gaussian Process
Feature Union
Outlier detection
Kernel Approximation
More neural networks


approximate timing
make exercises


introduce datasets in beginning
make sure everything runs under scikit-learn 0.17.1!!!


1) select datasets
2) outline "from scratch" parts
3) make sure everything is somewhat aligned, use other datasets
4) flesh out from scratch parts
5) exercises


01.1 : intro multi-class data?
01.2 : Add empirical risk minimization to 01.2, add overfitting / underfitting chart, elastic net?
01.3 : TODO

2.1 : use different dataset
2.2 : regression metrics?


GridSearchCV and metrics after models?!

3.1 other data? other models?
3.2 : add more feature selection!!

4.1 other models and datasets?

Use SVC less?

7.1 write!!
8.1 Write !!
9.1 todo

Outlier detection: time series!!

Urgent:
==========
GP
renumbering
5.3 not digits!!
feature selection forward / backward
out of core learning: add diagram
