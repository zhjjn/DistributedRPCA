Regression:
bike forecast (time series?)
census data?
forecast temperature?

classification?
train delay data
lending club credit
animal shelter

Unsupervised:
World Development Indicators
health insurance market
SF city employe salary
consumer complaints
coder survey
census data

time series:
world weather data
economic indicators:
http://www.assetmacro.com/market-data/

