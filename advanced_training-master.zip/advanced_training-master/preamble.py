import numpy as np
import matplotlib.pyplot as plt
import mglearn
import pandas as pd

plt.rcParams['image.interpolation'] = "none"
np.set_printoptions(precision=3)

np, mglearn, pd
